# Script d'installation des hooks Git
# Usage: ./install_hooks.ps1

$repoRoot = Resolve-Path "../../.."
$hooksSource = Join-Path $repoRoot "tools/workflow/git-hooks"
$hooksTarget = Join-Path $repoRoot ".git/hooks"

# VaÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©rifier que le dossier des hooks existe
if (-not (Test-Path $hooksTarget)) {
    Write-Host "Erreur: Le dossier .git/hooks n'existe pas!" -ForegroundColor Red
    exit 1
}

# Copier les hooks
Write-Host "Installation des hooks Git..." -ForegroundColor Cyan

$hooks = @("commit-msg", "pre-commit")
foreach ($hook in $hooks) {
    $source = Join-Path $hooksSource $hook
    $target = Join-Path $hooksTarget $hook
    
    if (Test-Path $source) {
        Copy-Item -Path $source -Destination $target -Force
        
        # Sous Windows, on ne peut pas rendre les fichiers exaÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©cutables
        # sous WSL ou Git Bash, ils le seront automatiquement
        Write-Host "aÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¢aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¦eeeÃƒÆ’Ã†â€™...aa"Å¡Ã‚Â¬Ãƒâ€¦"aÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¢e"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eeÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¦ Hook $hook installaÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©" -ForegroundColor Green
    } else {
        Write-Host "aÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¢aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¦eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¡aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â aÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¯aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¸aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â Hook $hook introuvable dans $hooksSource" -ForegroundColor Yellow
    }
}

# CraÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©er le modaÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¨le de message de commit
$commitTemplate = Join-Path $repoRoot "tools/workflow/templates/commit_message_template.txt"
git config --local commit.template $commitTemplate

Write-Host "`nConfiguration de Git termineaa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©e:" -ForegroundColor Cyan
Write-Host "- Hooks Git installaÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©s dans $hooksTarget" -ForegroundColor White
Write-Host "- Template de commit configuraÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©" -ForegroundColor White

Write-Host "`naÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â°aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¦eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¸aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¦eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â½aÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¢e"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eeÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â° Installation termineaa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©e avec succesaa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¨s!" -ForegroundColor Green
Write-Host "Pour utiliser le systaÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â¨me de commit enrichi, exaÃƒÆ’"Â "Ã¢â€žÂ¢ÃƒÆ’Ã†â€™"Ã‚Â aa"Å¡Ã‚Â¬a"Å¾Ã‚Â¢aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â 'aÃƒÆ’"Â "Ã¢â€žÂ¢"ÃƒÆ’...Ãƒâ€šÃ‚Â¡eÃƒÆ’Ã†â€™"Ã…Â¡ÃƒÆ’"Å¡Ãƒâ€šÃ‚Â©cutez:" -ForegroundColor Cyan
Write-Host "  ./tools/workflow/scripts/commit_with_context.ps1" -ForegroundColor White