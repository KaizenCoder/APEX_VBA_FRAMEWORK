Describe "Fix-ApexEncoding" {
    BeforeAll {
        Import-Module (Join-Path $PSScriptRoot "..\modules\EncodingCore.psm1")
    }
    
    Context "Pattern Replacement" {
        It "Should replace simple accents" {
            $content = "éèêë"
            $patterns = Get-EncodingPatterns
            foreach ($p in $patterns) {
                $content = $content -replace $p.Pattern, $p.Replacement
            }
            $content | Should -Be "eeee"
        }
        
        It "Should handle complex sequences" {
            $content = 'a""a"aa"a"aaa"''a""a"...e""'
            $patterns = Get-EncodingPatterns
            foreach ($p in $patterns) {
                $content = $content -replace $p.Pattern, $p.Replacement
            }
            $content | Should -Be ""
        }
    }
    
    Context "File Processing" {
        It "Should validate PowerShell syntax" {
            $content = "function Test-Function { Write-Host 'Test' }"
            Test-PowerShellSyntax $content | Should -Be $true
        }
        
        It "Should detect invalid syntax" {
            $content = "function Test-Function { Write-Host 'Test' "
            Test-PowerShellSyntax $content | Should -Be $false
        }
    }
} 