# Test-SessionWorkflow.ps1
# Script de test pour valider le workflow de gestion des sessions

# Forcer l'encodage UTF-8 sans BOM
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Variables de test
$sessionTitle = "Session de test automatise"
$objectives = @(
    "Valider New-SessionLog",
    "Tester Add-TaskToSession",
    "Verifier Complete-ApexSession"
)

Write-Host "=== Test du workflow de session ===" -ForegroundColor Cyan

# 1. Demarrer une session
Write-Host "`n1. Demarrage d'une nouvelle session..." -ForegroundColor Yellow
$sessionId = & .\Start-ApexSession.ps1 -Title $sessionTitle -Objectives $objectives

if (-not $sessionId) {
    Write-Host "aÃƒÆ’"Å¡Ãƒâ€šÃ‚ÂÃƒÆ’..."Ã¢â€žÂ¢ aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â°chec du demarrage de la session" -ForegroundColor Red
    exit 1
}

Write-Host "aÃƒÆ’..."aa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¦ Session demarree avec succes" -ForegroundColor Green

# 2. Ajouter une teche
Write-Host "`n2. Ajout d'une teche..." -ForegroundColor Yellow
$result = & .\Add-TaskToSession.ps1 -Name "Teche de test" -Module "core" -Status "aÃƒÆ’..."aa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¦ Termine" -Comment "Test reussi"

if (-not $result) {
    Write-Host "aÃƒÆ’"Å¡Ãƒâ€šÃ‚ÂÃƒÆ’..."Ã¢â€žÂ¢ aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â°chec de l'ajout de teche" -ForegroundColor Red
    exit 1
}

Write-Host "aÃƒÆ’..."aa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¦ Teche ajoutee avec succes" -ForegroundColor Green

# 3. Terminer la session
Write-Host "`n3. Finalisation de la session..." -ForegroundColor Yellow
$result = & .\Complete-ApexSession.ps1 -Summary "Session de test terminee avec succes"

if (-not $result) {
    Write-Host "aÃƒÆ’"Å¡Ãƒâ€šÃ‚ÂÃƒÆ’..."Ã¢â€žÂ¢ aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â°chec de la finalisation de la session" -ForegroundColor Red
    exit 1
}

Write-Host "aÃƒÆ’..."aa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¦ Session terminee avec succes" -ForegroundColor Green

Write-Host "`n=== Tests termines avec succes ===" -ForegroundColor Cyan 