# New-SessionLog.ps1
# Script pour creer et gerer les logs de session de developpement APEX VBA Framework
# Ce script peut aÃƒÆ’"Å¡Ãƒâ€šÃ‚Âªtre utilise independamment du processus de commit

# Parametres
param (
    [Parameter(Mandatory=$false)]
    [ValidateSet("New", "Update", "Complete")]
    [string]$Action = "New",
    
    [Parameter(Mandatory=$false)]
    [string]$SessionId = "",
    
    [Parameter(Mandatory=$false)]
    [string]$Title = "",
    
    [Parameter(Mandatory=$false)]
    [string[]]$Objectives = @(),
    
    [Parameter(Mandatory=$false)]
    [switch]$Interactive
)

# Force l'encodage UTF-8
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Trouver le module ApexWSLBridge de faaÃƒÆ’"Å¡Ãƒâ€šÃ‚Â§on flexible
$modulePath = $null
$possiblePaths = @(
    (Join-Path -Path (Split-Path -Parent $PSScriptRoot) -ChildPath "..\..\powershell\ApexWSLBridge.psm1"),
    "D:\Dev\Apex_VBA_FRAMEWORK\tools\powershell\ApexWSLBridge.psm1",
    (Get-ChildItem -Path "D:\Dev\Apex_VBA_FRAMEWORK\tools" -Recurse -Filter "ApexWSLBridge.psm1" -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName)
)

foreach ($path in $possiblePaths) {
    if ($path -and (Test-Path $path)) {
        $modulePath = $path
        break
    }
}

if ($modulePath) {
    Import-Module $modulePath -Force
}

# Variables globales
$script:projectRoot = "D:\Dev\Apex_VBA_FRAMEWORK"
$script:logsRoot = Join-Path -Path $PSScriptRoot -ChildPath "..\logs"
$script:sessionsDir = Join-Path -Path $script:logsRoot -ChildPath "sessions"
$script:templatePath = Join-Path -Path $PSScriptRoot -ChildPath "..\templates\session_log_template.md"
$script:currentSession = $null

# Assurer que les repertoires existent
if (-not (Test-Path $script:logsRoot)) {
    New-Item -Path $script:logsRoot -ItemType Directory -Force | Out-Null
}

if (-not (Test-Path $script:sessionsDir)) {
    New-Item -Path $script:sessionsDir -ItemType Directory -Force | Out-Null
}

# Fonctions principales
function New-ApexSession {
    param (
        [string]$Title = "",
        [string[]]$Objectives = @(),
        [switch]$Interactive
    )
    
    # Generer un ID de session unique
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $sessionId = "session_$timestamp"
    $sessionPath = Join-Path -Path $script:sessionsDir -ChildPath "$sessionId.md"
    
    # Si titre vide, demander aÃƒÆ’"Å¡Ãƒâ€šÃ‚Â  l'utilisateur
    if ([string]::IsNullOrWhiteSpace($Title) -and $Interactive) {
        $Title = Read-Host "Titre de la session"
    }
    
    if ([string]::IsNullOrWhiteSpace($Title)) {
        $Title = "Session de travail - $(Get-Date -Format 'dd MMMM yyyy')"
    }
    
    # Creer le contenu du log
    $content = Get-Content -Path $script:templatePath -Raw
    
    # Remplacer les variables dans le modele
    $dateStr = Get-Date -Format "dd MMMM yyyy"
    $content = $content.Replace('{{DATE}}', $dateStr)
    $content = $content -replace '# ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â­ Session de travail aa"Å¡Ã‚Â¬" .*', "# ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â­ $Title"
    
    # Ajouter les objectifs
    if ($Objectives.Count -gt 0) {
        $objectivesText = $Objectives | ForEach-Object { "- [ ] $_" } | Join-String -Separator "`n"
        $content = $content -replace '- \[ \] Fonctionnalite 1(\r?\n)?- \[ \] Test associe(\r?\n)?- \[ \] Documentation associee', $objectivesText
    }
    
    # aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â°crire le fichier
    $utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($sessionPath, $content, $utf8NoBom)
    
    # Stocker la session courante
    $script:currentSession = @{
        Id = $sessionId
        Path = $sessionPath
        StartTime = Get-Date
        Title = $Title
        Objectives = $Objectives
    }
    
    Write-Host "Session '$Title' creee: $sessionPath" -ForegroundColor Green
    return $sessionId
}

function Update-ApexSession {
    param (
        [string]$SessionId,
        [hashtable]$Updates
    )
    
    # Si l'ID de session n'est pas specifie, utiliser la session courante
    if ([string]::IsNullOrWhiteSpace($SessionId) -and $null -ne $script:currentSession) {
        $SessionId = $script:currentSession.Id
    }
    
    if ([string]::IsNullOrWhiteSpace($SessionId)) {
        Write-Host "Erreur: Aucune session specifiee ou en cours" -ForegroundColor Red
        return $false
    }
    
    # Trouver le fichier de session
    $sessionPath = Join-Path -Path $script:sessionsDir -ChildPath "$SessionId.md"
    
    if (-not (Test-Path $sessionPath)) {
        Write-Host "Erreur: Session introuvable: $SessionId" -ForegroundColor Red
        return $false
    }
    
    # Lire le contenu actuel
    $content = Get-Content -Path $sessionPath -Raw
    
    # Mettre aÃƒÆ’"Å¡Ãƒâ€šÃ‚Â  jour selon les elements fournis
    foreach ($key in $Updates.Keys) {
        switch ($key) {
            "AddTask" {
                $task = $Updates[$key]
                $taskLine = "| $($task.Name) | $($task.Module) | $($task.Status) | $($task.Comment) |"
                $content = $content -replace "(\| +\| +\| +\| +\|)", "$taskLine`n$1"
            }
            "AddPrompt" {
                $prompt = $Updates[$key]
                $promptLine = "| $($prompt.Time) | $($prompt.Agent) | $($prompt.Query) |"
                $content = $content -replace "(\| +\| +\| +\|)", "$promptLine`n$1"
            }
            "AddTest" {
                $test = $Updates[$key]
                $content = $content -replace "(## ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â­ Session de travail aa"Å¡Ã‚Â¬" {{DATE}}\n\n)", "$1- [ ] $test`n"
            }
            "AddModule" {
                $module = $Updates[$key]
                $content = $content -replace "(## ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â­ Session de travail aa"Å¡Ã‚Â¬" {{DATE}}\n\n)", "$1- `$module`n"
            }
            "SetCommit" {
                $commit = $Updates[$key]
                $commitText = "$($commit.Type)($($commit.Scope)): $($commit.Title)`n`n$($commit.Body)"
                $content = $content -replace "(## ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â­ Session de travail aa"Å¡Ã‚Â¬" {{DATE}}\n\n).*?(---)", "$1$commitText`n`n---"
            }
            "SetSummary" {
                $summary = $Updates[$key]
                $content = $content -replace "(## ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â­ Session de travail aa"Å¡Ã‚Â¬" {{DATE}}\n\n).*?($)", "$1$summary`n"
            }
        }
    }
    
    # aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â°crire le contenu mis aÃƒÆ’"Å¡Ãƒâ€šÃ‚Â  jour
    $enc = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllLines($sessionPath, $content, $enc)
    
    Write-Host "Session mise a jour: $sessionPath" -ForegroundColor Green
    return $true
}

function Complete-ApexSession {
    param (
        [string]$SessionId,
        [string]$Summary = ""
    )
    
    # Si l'ID de session n'est pas specifie, utiliser la session courante
    if ([string]::IsNullOrWhiteSpace($SessionId) -and $null -ne $script:currentSession) {
        $SessionId = $script:currentSession.Id
    }
    
    if ([string]::IsNullOrWhiteSpace($SessionId)) {
        Write-Host "Erreur: Aucune session specifiee ou en cours" -ForegroundColor Red
        return $false
    }
    
    # Trouver le fichier de session
    $sessionPath = Join-Path -Path $script:sessionsDir -ChildPath "$SessionId.md"
    
    if (-not (Test-Path $sessionPath)) {
        Write-Host "Erreur: Session introuvable: $SessionId" -ForegroundColor Red
        return $false
    }
    
    # Calculer la duree de la session
    $duration = "N/A"
    if ($null -ne $script:currentSession -and $SessionId -eq $script:currentSession.Id) {
        $endTime = Get-Date
        $duration = "{0:hh\:mm\:ss}" -f ($endTime - $script:currentSession.StartTime)
    }
    
    # Mettre aÃƒÆ’"Å¡Ãƒâ€šÃ‚Â  jour le resume si fourni
    if (-not [string]::IsNullOrWhiteSpace($Summary)) {
        $updates = @{
            "SetSummary" = $Summary
        }
        Update-ApexSession -SessionId $SessionId -Updates $updates | Out-Null
    }
    
    # Lire le contenu
    $content = Get-Content -Path $sessionPath -Raw
    
    # Ajouter la duree de la session
    $content = $content -replace "(ÃƒÆ’Ã‚Â°Ãƒâ€¦Ã‚Â¸Ãƒâ€šÃ‚Â§Ãƒâ€šÃ‚Â­ Session de travail aa"Å¡Ã‚Â¬" {{DATE}}\n)", "$1\n**Duree de la session**: $duration\n"
    
    # aaa"Å¡Ã‚Â¬Ãƒâ€šÃ‚Â°crire le contenu mis aÃƒÆ’"Å¡Ãƒâ€šÃ‚Â  jour
    $enc = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllLines($sessionPath, $content, $enc)
    
    # Reinitialiser la session courante
    if ($null -ne $script:currentSession -and $SessionId -eq $script:currentSession.Id) {
        $script:currentSession = $null
    }
    
    Write-Host "Session completee: $sessionPath" -ForegroundColor Green
    Write-Host "Duree: $duration" -ForegroundColor Cyan
    
    return $true
}

function Get-CurrentSession {
    return $script:currentSession
}

function Add-TaskToSession {
    param (
        [string]$SessionId = "",
        [string]$Name,
        [string]$Module,
        [string]$Status = "En cours",
        [string]$Comment = ""
    )
    
    $updates = @{
        "AddTask" = @{
            "Name" = $Name
            "Module" = $Module
            "Status" = $Status
            "Comment" = $Comment
        }
    }
    
    return Update-ApexSession -SessionId $SessionId -Updates $updates
}

function Add-PromptToSession {
    param (
        [string]$SessionId = "",
        [string]$Agent = "Claude",
        [string]$Query
    )
    
    $time = Get-Date -Format "HH:mm"
    
    $updates = @{
        "AddPrompt" = @{
            "Time" = $time
            "Agent" = $Agent
            "Query" = $Query
        }
    }
    
    return Update-ApexSession -SessionId $SessionId -Updates $updates
}

function Add-CommitToSession {
    param (
        [string]$SessionId = "",
        [string]$Type = "feat",
        [string]$Scope = "core",
        [string]$Title,
        [string]$Body = ""
    )
    
    $updates = @{
        "SetCommit" = @{
            "Type" = $Type
            "Scope" = $Scope
            "Title" = $Title
            "Body" = $Body
        }
    }
    
    return Update-ApexSession -SessionId $SessionId -Updates $updates
}

# Exporter les fonctions pour utilisation externe
Export-ModuleMember -Function New-ApexSession
Export-ModuleMember -Function Update-ApexSession
Export-ModuleMember -Function Complete-ApexSession
Export-ModuleMember -Function Get-CurrentSession
Export-ModuleMember -Function Add-TaskToSession
Export-ModuleMember -Function Add-PromptToSession
Export-ModuleMember -Function Add-CommitToSession

# Logique principale
switch ($Action) {
    "New" { 
        New-ApexSession -Title $Title -Objectives $Objectives -Interactive:$Interactive 
    }
    "Update" {
        if ([string]::IsNullOrWhiteSpace($SessionId)) {
            Write-Host "Erreur: L'ID de session est requis pour l'action 'Update'" -ForegroundColor Red
        } else {
            Update-ApexSession -SessionId $SessionId -Updates @{}
        }
    }
    "Complete" {
        Complete-ApexSession -SessionId $SessionId -Summary $Summary
    }
} 