# Script PowerShell de mise à jour du dashboard
Write-Host 'Dashboard mis à jour.'