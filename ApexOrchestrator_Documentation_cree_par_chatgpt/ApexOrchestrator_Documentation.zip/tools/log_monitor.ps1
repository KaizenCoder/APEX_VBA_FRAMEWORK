# Script PowerShell de surveillance des erreurs
Write-Host 'Monitoring actif.'