# Tableau de bord VSCode – Performance

_Mis à jour automatiquement toutes les 30 min_