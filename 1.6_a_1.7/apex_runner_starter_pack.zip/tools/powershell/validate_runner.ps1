# Validate that Apex runner executes correctly
Write-Host "=== Validation Runner Apex ==="
$runnerPath = "D:\Dev\Apex_VBA_FRAMEWORK\src\Core\Runners\clsCoreDemoRunner.cls"
$logPath = "D:\Dev\Apex_VBA_FRAMEWORK\logs\demo_runner.log"

if (Test-Path $runnerPath) {
    Write-Host "Runner class file exists: OK"
} else {
    Write-Warning "Runner class file missing!"
}

if (Test-Path $logPath) {
    Write-Host "Log file exists: OK"
    Get-Content $logPath | Select-String "Execution terminée"
} else {
    Write-Warning "Log file not found"
}
