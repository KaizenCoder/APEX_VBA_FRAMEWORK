# Rapport Runner - JJ/MM/AAAA

## Action traitée
- Validation de [Nom du Runner] ou création de [Script/Fichier]

## Résultat
- [Succès / Échec / À revoir]

## Détails techniques
- [Logs générés, nom des fichiers, chemins, valeurs injectées]

## Étapes suivantes
- [Ce qu’il reste à faire / à valider]

## Tâches synchronisées avec Claude
- [Oui/Non] – [Commentaire]

## Fichiers générés
- [Fichiers .cls / .bas / .ps1] avec chemins complets
